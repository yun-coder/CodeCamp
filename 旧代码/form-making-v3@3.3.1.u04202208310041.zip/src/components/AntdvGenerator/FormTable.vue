<template>
  <div class="antd-form-table" :class="{'is-disabled': disableddata}">
    <a-table
      :dataSource="paging ? pagingData : tableData" 
      :pagination="false" bordered
      :class="{'antd-form-table-pc': !preview}"
      v-show="(preview && platform != 'mobile') || !preview"
      table-layout="auto"
      :scroll="{x: 'max-content'}"
      :size="tableSize"
    >
        <a-table-column
          v-if="showControl"
          :scopedSlots="{ customRender: '#' }"
          title="#"
          data-index="#"
          key="#"
          fixed="left"
          :width="80">
          <template #default="{index}">
            <div class="scope-index">
              <span>{{(paging ? pageSize * (currentPage - 1) : 0) + index + 1}}</span>
            </div>
            <div class="scope-action">
              
              <a-popconfirm  v-if="!printRead && isDelete" :title="$t('fm.description.deleteConfirm')" @confirm="handleRemove((paging ? pageSize * (currentPage - 1) : 0) + index)">
          
                <a-button :disabled="disableddata" type="primary" danger shape="circle"  size="small"><i class="iconfont icon-trash" style="font-size: 12px; margin: 5px;"></i></a-button>
                
              </a-popconfirm>
              <span v-if="printRead || !isDelete">{{(paging ? pageSize * (currentPage - 1) : 0) + index + 1}}</span>
            </div>
          </template>
        </a-table-column>
        <a-table-column v-if="columns.length==0"></a-table-column>
        <template v-else>
          <template v-for="column in columns" :key="column.key">
            <a-table-column 
              :key="column.key"
              v-if="displayFields[column.model]"
              :data-index="column.key"
              :title="column.options.hideLabel ? '' : column.name"
              :width="column.options.width"
              :class="column.options.required ? 'required' : ''"
              :scopedSlots="{ customRender: column.key }"
              :fixed="column.options.fixedColumn ? (column.options.fixedColumnPosition || 'left') : false"
            >
              <template #default="{record, index}">
                <a-form-item 
                  validateFirst
                  :ref="`${name}-item`" 
                  :name="isDialog ? [dialogName, name, (paging ? pageSize * (currentPage - 1) : 0) + index, column.model]
                   : [name, (paging ? pageSize * (currentPage - 1) : 0) + index, column.model]" 
                  :rules="rules[isDialog ? `${dialogName}.${name}.${column.model}` : `${name}.${column.model}`]"
                  :colon="false">
                  <GenerateElementItem 
                    :edit="!tableDisabledFields[index][column.model] && !disableddata"
                    :blanks="blanks" 
                    :is-table="true" 
                    :widget="column" 
                    v-model="record[column.model]" 
                    :models="tableData[(paging ? pageSize * (currentPage - 1) : 0) + index]" 
                    :remote="remote" 
                    :remote-option="remoteOption"
                    :row-index="(paging ? pageSize * (currentPage - 1) : 0) + index"
                    :table-name="name"
                    :event-function="eventFunction"
                    :data-source-value="dataSourceValue"
                    @on-table-change="handleTableChange"
                    :container-key="containerKey"
                    :print-read="printRead"
                    :config="config"
                    v-if="!tableHideFields?.[index]?.[column.model]"
                    :is-dialog="isDialog"
                    :dialog-name="dialogName"
                    >
                    
                    <template v-slot:[blank.name] v-for="blank in blanks">
                      <slot :name="blank.name" :model="record"></slot>
                    </template>
                  </GenerateElementItem>
                </a-form-item>

              </template>
              
            </a-table-column>
          </template>
          
        </template>
      <!-- </a-table-column-group> -->
    </a-table>

    <div class="antd-form-table-mobile"
      v-show="(preview && platform === 'mobile') || !preview"
      :style="{'display': (preview && platform === 'mobile') ? 'block' : ''}"
    >
      <div class="antd-form-table-mobile-item"
        v-for="(t, index) in (paging ? pagingData : tableData)"
        :key="(paging ? pageSize * (currentPage - 1) : 0) + index"
      >
        <div class="antd-form-table-mobile-item__top" v-if="showControl">
          <span># {{(paging ? pageSize * (currentPage - 1) : 0) + index + 1}}</span>
          <a-popconfirm  v-if="!printRead && isDelete" :title="$t('fm.description.deleteConfirm')" @confirm="handleRemove((paging ? pageSize * (currentPage - 1) : 0) + index)">
          
            <a-button :disabled="disableddata" type="primary" danger shape="circle"  size="small"><i class="iconfont icon-trash" style="font-size: 12px; margin: 5px;"></i></a-button>
            
          </a-popconfirm>
        </div>
        <div class="antd-form-table-mobile-item__content">
          <a-space direction="vertical" style="width: 100%;">
            <template v-for="column in columns" :key="column.key" >
              <a-form-item 
                validateFirst
                :ref="`${name}-item`"
                v-if="displayFields[column.model]"
                :label="column.options.hideLabel ? '' : column.name"
                :class="{
                  'no-label-form-item': column.options.isLabelWidth && column.options.labelWidth == 0,
                  'no-label-left': column.name === ''
                }"
                :name="isDialog ? [dialogName, name, (paging ? pageSize * (currentPage - 1) : 0) + index, column.model]
                  : [name, (paging ? pageSize * (currentPage - 1) : 0) + index, column.model]" 
                :rules="rules[isDialog ? `${dialogName}.${name}.${column.model}` : `${name}.${column.model}`]"
                :colon="false">
                <GenerateElementItem
                  :edit="!tableDisabledFields[index][column.model] && !disableddata" 
                  :blanks="blanks" 
                  :is-table="true" 
                  :widget="column" 
                  v-model="tableData[(paging ? pageSize * (currentPage - 1) : 0) + index][column.model]" 
                  :models="tableData[(paging ? pageSize * (currentPage - 1) : 0) + index]" 
                  :remote="remote" 
                  :remote-option="remoteOption" 
                  :row-index="(paging ? pageSize * (currentPage - 1) : 0) + index"
                  :table-name="name"
                  :event-function="eventFunction"
                  :data-source-value="dataSourceValue"
                  @on-table-change="handleTableChange"
                  :container-key="containerKey"
                  :print-read="printRead"
                  :is-mobile="true"
                  :config="config"
                  v-if="!tableHideFields?.[index]?.[column.model]"
                  :is-dialog="isDialog"
                  :dialog-name="dialogName"
                >

                  <template v-slot:[blank.name] v-for="blank in blanks">
                    <slot :name="blank.name" :model="tableData[(paging ? pageSize * (currentPage - 1) : 0) + index]"></slot>
                  </template>
                </GenerateElementItem>
              </a-form-item>
            </template>
          </a-space>
        </div>
      </div>
    </div>

    <a-row>
      <a-col :md="(preview && platform != 'mobile') || !preview ? 12 : 24" :xs="24" :sm="24">
        <a-button  type="link" @click="handleAddRow" v-if="!disableddata && isAdd">
          <i class="iconfont icon-plus" style="font-size: 12px; margin: 5px;"></i>{{$t('fm.actions.add')}}
        </a-button>
        
      </a-col>
      <a-col :md="((preview && platform != 'mobile') || !preview) && !disableddata ? 12 : 24" :xs="24" :sm="24">
        <a-pagination
          style="float: right; padding-top: 5px;white-space: nowrap;"
          layout="total, prev, pager, next"
          v-model:page-size="pageSize"
          v-model:current="currentPage"
          :total="tableData.length"
          :pager-count="5"
          @change="handlePageChange"
          v-if="paging && tableData.length"
          show-less-items
        >
        </a-pagination>
      </a-col>
    </a-row>
  </div>
</template>

<script>
import { defineAsyncComponent } from 'vue'

export default {
  components: {
    GenerateElementItem: defineAsyncComponent(() => import('./GenerateElementItem.vue'))
  },
  props: ['config', 'columns', 'value', 'models', 'remote', 'blanks', 'disableddata', 'rules', 'name', 'remoteOption', 'preview', 'platform', 'dataSourceValue', 'eventFunction', 'widget', 'containerKey', 'printRead', 'paging', 'pageSize', 'isAdd', 'isDelete', 'showControl', 'isDialog', 'dialogName'],
  emits: ['update:value'],
  data () {
    return {
      tableData: this.value ?? [],
      displayFields: {},
      changeItem: {},
      pagingData: [],
      currentPage: 1,
      tableHideFields: this.value ? this.value.map(item => Object.keys(item).map(o => ({[o]: false}))) : [],
      tableDisabledFields: this.value ? this.value.map(item => Object.keys(item).map(o => ({[o]: false}))) : [],
    }
  },
  created () {
    for (let i = 0; i < this.columns.length; i++) {
      this.displayFields[this.columns[i].model] = !this.columns[i].options.hidden
    }

    this.loadPagingData()
  },
  computed: {
    tableSize () {
      switch (this.config.size) {
        case 'large': return 'default'; break;
        case 'default': return 'middle'; break;
        case 'small': return 'small'; break;
      }
    }
  },
  methods: {
    handleAddRow () {
      let item = {}
      let hideItem = {}
      let disabledItem = {}
      for (let i = 0; i < this.columns.length; i++) {
        if (this.columns[i].type === 'blank') {
          item[this.columns[i].model] = this.columns[i].options.defaultType == 'String' ? '' : (this.columns[i].options.defaultType == 'Object' ? {} : [])
        } else if (this.columns[i].type === 'component' || this.columns[i].type === 'link' || this.columns[i].type === 'button') {
          item[this.columns[i].model] = undefined
        } else {
          item[this.columns[i].model] = this.columns[i].options.defaultValue
        }
        hideItem[this.columns[i].model] = false
        disabledItem[this.columns[i].model] = false
      }

      this.tableData.push(item)
      this.tableHideFields.push(hideItem)
      this.tableDisabledFields.push(disabledItem)

      if (this.widget.events && this.widget.events.onRowAdd) {
        let funcKey = this.widget.events.onRowAdd

        this.eventFunction[funcKey]({
          rowIndex: this.tableData.length - 1, 
          field: this.widget.model,
          currentRef: this
        })
      }

      this.changeItem = {}

      if (this.paging) {
        this.$nextTick(() => {
          if (this.tableData.length > this.currentPage * this.pageSize) {
            this.currentPage = parseInt((this.tableData.length - 1) / this.pageSize) + 1
          }

          this.loadPagingData()
        })
      }
    },

    handleRemove (index) {
      this.tableData.splice(index, 1)

      if (this.widget.events && this.widget.events.onRowRemove) {
        let funcKey = this.widget.events.onRowRemove

        this.eventFunction[funcKey]({
          removeIndex: index, 
          field: this.widget.model,
          currentRef: this
        })
      }

      this.changeItem = {}

      this.pagingData = []

      if (this.paging) {
        this.$nextTick(() => {
          if (this.tableData.length % this.pageSize == 0 && this.currentPage > parseInt(this.tableData.length / this.pageSize)) {
            this.currentPage = parseInt(this.tableData.length / this.pageSize)
          }

          this.loadPagingData()
        })
      }
    },
    hide (fields) {
      Object.keys(this.displayFields).forEach(key => {
        
        if (fields.indexOf(key) >= 0) {
          this.displayFields[key] = false
        }
      })
      
      this.displayFields = {...this.displayFields}
    },
    display (fields) {
      Object.keys(this.displayFields).forEach(key => {
        if (fields.indexOf(key) >= 0) {
          this.displayFields[key] = true
        }
      })
      this.displayFields = {...this.displayFields}
    },
    hideChild (rowIndex, fields) {
      fields.forEach(field => {
        this.tableHideFields[rowIndex][field] = true
      })
    },
    displayChild (rowIndex, fields) {
      fields.forEach(field => {
        this.tableHideFields[rowIndex][field] = false
      })
    },
    disabled (fields, disabled) {

      for (let i = 0; i < this.columns.length; i++) {
        if (fields.indexOf(this.columns[i].model) >= 0) {
            
          this.columns[i].options.disabled = disabled
        }
      }
    },
    disabledChild (rowIndex, fields, disabled) {
      fields.forEach(field => {
        this.tableDisabledFields[rowIndex][field] = disabled
      })
    },
    handleTableChange (value) {
      this.changeItem = value
    },

    handlePageChange (val) {
      this.currentPage = val

      this.pagingData = []

      this.$nextTick(() => {
        this.loadPagingData()

        this.$refs[this.name + '-item'].forEach(item => {
          item.clearValidate()
        })
      })

      if (this.widget && this.widget.events && this.widget.events.onPageChange) {
        let funcKey = this.widget.events.onPageChange

        this.eventFunction[funcKey]({
          currentPage: val, 
          field: this.widget.model,
          currentRef: this
        })
      }
    },

    loadPagingData () {
      let beginIndex = (this.currentPage - 1) * this.pageSize

      let endIndex = beginIndex + this.pageSize

      this.pagingData = this.tableData?.slice(beginIndex, endIndex)
    }
  },
  watch: {
    value (val) {
      this.tableData = val

      let hideFields = []
      let disabledFields = []
      for (let i = 0; i < this.value?.length; i++) {
        let row = this.value[i]
        let rowArray = Object.keys(row)
        let hideRow = {}
        let disabledRow = {}
        for (let f = 0; f < rowArray.length; f++) {
          hideRow[rowArray[f]] = this.tableHideFields?.[i]?.[rowArray[f]] || false
          disabledRow[rowArray[f]] = this.tableDisabledFields?.[i]?.[rowArray[f]] || false
        }

        hideFields.push(hideRow)
        disabledFields.push(disabledRow)
      }

      this.tableHideFields = hideFields
      this.tableDisabledFields = disabledFields
    },
    'tableData': {
      deep: true,
      handler (val) {

        this.loadPagingData()

        this.$emit('update:value', val)

        if (this.changeItem.haveEvent) {

          this.eventFunction[this.changeItem.haveEvent](this.changeItem)
        }
      }
    }
  }
}
</script>

<style lang="scss">
.fm-form .fm-form-item .antd-form-table{
  .ant-form-item{
    .ant-col{
      max-width: none;
    }

    .ant-form-item-label{
      flex: 0 0 auto;
    }

    .ant-form-item-control{
      flex: 1;
    }
  }

  .ant-form-item{
    .ant-form-item-label{
      width: v-bind(labelWidth);
    }
  }

  .no-label-left{
    .ant-form-item-control{
      margin-left: v-bind(labelWidth);
    }
  }
}

.antd-form-table{

  .ant-form-item{
    margin-bottom: 0;
  }

  .ant-form-explain{
    position: absolute;
    margin-top: -5px;
  }

  td{
    vertical-align: top;
  }

  .ant-table th.required div::before{
    content: '*';
    color: #f56c6c;
    margin-right: 4px;
    background: transparent;
    vertical-align: top;
  }

  .ant-table-body{
    overflow: auto;
  }

  .scope-action{
    display: none;
  }

  .scope-index{
    display: block;
  }

  .ant-table-row:hover{
    .scope-action{
      display: block;
      .el-button{
        padding: 3px;
      }
    }

    .scope-index{
      display: none;
    }
  }

  .ant-table-row-hover{
    .scope-action{
      display: block;
      .el-button{
        padding: 3px;
      }
    }

    .scope-index{
      display: none;
    }
  }

  .ant-table-pagination{
    display: none;
  }

  .ant-empty-normal{
    margin: 0;
  }

  .antd-form-table-pc{
    display: block;
  }

  .antd-form-table-mobile{
    display: none;

    .antd-form-table-mobile-item{
      border: 1px solid #e8e8e8;
      margin-bottom: 10px;

      .antd-form-table-mobile-item__top{
        height: 36px;
        line-height: 36px;
        padding: 0 10px;
        background:  #fafafa;
        border-bottom: 1px solid #e8e8e8;
        font-weight: 500;

        button{
          float: right;
          margin-top: 4px;
        }
      }

      .antd-form-table-mobile-item__content{
        padding: 8px;
      }

    }
  }
}

html.dark{

  .antd-form-table{

    .antd-form-table-mobile{

      .antd-form-table-mobile-item{
        border: 1px solid #303030;

        .antd-form-table-mobile-item__top{
          background:  #1d1d1d;
          border-bottom: 1px solid #303030;
        }
      }
    }
  }
}

@media screen and (max-width: 768px) {
  .antd-form-table{
    .antd-form-table-pc{
      display: none;
    }

    .antd-form-table-mobile{
      display: block;
    }
  }
}
</style>
