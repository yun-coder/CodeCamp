<template>
  <span :class="{'print-read-label': printRead}">
    <template v-if="widget.type == 'blank'">
      <div :style="{width: isTable ? '100%' : widget.options.width}">
        <slot :name="widget.model" :model="dataModels"></slot>
      </div>
      
    </template>

    <template v-if="widget.type == 'component'">  
      <div :style="{width: isTable ? '100%' : widget.options.width}">
        <component :is="`component-${widget.key}-${key}`" :key="key" v-model="dataModel" :ref="'fm-'+widget.model"></component>
      </div>
    </template>

    <template v-if="widget.type == 'custom'">  
      <div :style="{width: isTable ? '100%' : widget.options.width}">
        <component 
          :is="widget.el" 
          v-model="dataModel"
          :width="widget.options.width"
          :height="widget.options.height"
          :size="config.size"
          :placeholder="widget.options.placeholder"
          :readonly="widget.options.readonly"
          :disabled="!edit || widget.options.disabled"
          :editable="widget.options.editable"
          :clearable="widget.options.clearable"
          :ref="'fm-'+widget.model"
          :print-read="printRead"
          v-bind="widget.options.extendProps"
          v-on="dynamicEvents"
        ></component>
      </div>
    </template>

    <template v-if="widget.type == 'input'" >
      <template v-if="printRead">
        <span>{{dataModel}}</span>
      </template>
      <template v-else>
        <template v-if="widget.options.showPassword" >
          <a-input-password 
            :type="widget.options.dataTypeCheck ? widget.options.dataType : 'text'"
            v-model:value="dataModel"
            :disabled="!edit || widget.options.disabled"
            :placeholder="widget.options.placeholder"
            :style="{width: isTable ? '100%' : widget.options.width}"
            :ref="'fm-'+widget.model"
            :size="config.size"
            :allow-clear="widget.options.clearable"
            @focus="handleOnFocus"
            @blur="handleOnBlur"
            autocomplete="off"
          />
        </template>
        <template v-else>
          <a-input
            :type="widget.options.dataTypeCheck ? widget.options.dataType : 'text'"
            v-model:value="dataModel"
            :disabled="!edit || widget.options.disabled"
            :placeholder="widget.options.placeholder"
            :style="{width: isTable ? '100%' : widget.options.width}"
            :ref="'fm-'+widget.model"
            :size="config.size"
            :allow-clear="widget.options.clearable"
            :maxlength="widget.options.maxlength"
            :show-count="widget.options.showWordLimit"
            @focus="handleOnFocus"
            @blur="handleOnBlur"
            autocomplete="off"
          ></a-input>
          
        </template>
      </template>
    </template>

    <template v-if="widget.type == 'textarea'">
      <template v-if="printRead">
        <pre>{{dataModel}}</pre>
      </template>
      <template v-else>
        <a-textarea type="textarea" :rows="widget.options.rows"
          v-model:value="dataModel"
          :disabled="!edit || widget.options.disabled"
          :placeholder="widget.options.placeholder"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :ref="'fm-'+widget.model"
          :allow-clear="widget.options.clearable"
          :size="config.size"
          :maxlength="Number(widget.options.maxlength)"
          :show-count="widget.options.showWordLimit"
          :autosize="widget.options.autosize"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
        ></a-textarea>
      </template>
    </template>

    <template v-if="widget.type == 'number'">
      <template v-if="printRead">
        <span>{{dataModel.toFixed(widget.options.precision)}}</span>
      </template>
      <template v-else>
        <a-input-number 
          v-model:value="dataModel" 
          :style="{width: isTable ? '100%' : widget.options.width}"
          :step="widget.options.step"
          :disabled="!edit || widget.options.disabled"
          :min="widget.options.min"
          :max="widget.options.max"
          :controls-position="widget.options.controlsPosition"
          :precision="widget.options.precision"
          :controls="widget.options.controls"
          :ref="'fm-'+widget.model"
          :size="config.size"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
        ></a-input-number>
      </template>
    </template>

    <template v-if="widget.type == 'radio'">
      <template v-if="printRead">
        <template v-if="widget.options.remote">
          {{
            remoteOptions.find(item => item.value == dataModel) 
            && remoteOptions.find(item => item.value == dataModel).label
          }}
        </template>
        <template v-else>
          {{
            widget.options.showLabel ? 
            (widget.options.options.find(item => item.value == dataModel) && widget.options.options.find(item => item.value == dataModel).label) :
            dataModel
          }}
        </template>
      </template>
      <template v-else>
        <a-radio-group v-model:value="dataModel"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :disabled="!edit || widget.options.disabled"
          :size="config.size"
          :ref="'fm-'+widget.model"
        >
          <a-radio
            :style="{display: widget.options.inline ? 'inline-block' : 'block'}"
            :value="item.value" v-for="(item, index) in (widget.options.remote ? remoteOptions : widget.options.options)" :key="index"
          >
            <template v-if="widget.options.remote">{{item.label}}</template>
            <template v-else>{{widget.options.showLabel ? item.label : item.value}}</template>
          </a-radio>
        </a-radio-group>
      </template>
    </template>

    <template v-if="widget.type == 'checkbox'">
      <template v-if="printRead">
        <template v-if="widget.options.remote">
          {{
            dataModel.map(dm => 
              remoteOptions.find(item => item.value == dm) 
              && remoteOptions.find(item => item.value == dm).label
            ).join('、')
            
          }}
        </template>
        <template v-else>
          {{
            widget.options.showLabel ? 
            dataModel.map(dm => widget.options.options.find(item => item.value == dm) && widget.options.options.find(item => item.value == dm).label).join('、') :
            dataModel.join('、')
          }}
        </template>
      </template>
      <template v-else>
        <a-checkbox-group v-model:value="dataModel"
          :style="{
            width: isTable ? '100%' : widget.options.width,
            display: 'flex',
            'flex-wrap': 'wrap',
            'flex-direction': widget.options.inline ? 'row' : 'column'
          }"
          :disabled="!edit || widget.options.disabled"
          :size="config.size"
          :ref="'fm-'+widget.model"
        >
          <a-checkbox
            
            :style="{
              'line-height': '30px'
            }"
            :value="item.value" v-for="(item, index) in (widget.options.remote ? remoteOptions : widget.options.options)" :key="index"
          >
            <template v-if="widget.options.remote">{{item.label}}</template>
            <template v-else>{{widget.options.showLabel ? item.label : item.value}}</template>
          </a-checkbox>
        </a-checkbox-group>
      </template>
    </template>

    <template v-if="widget.type == 'time'">
      <template v-if="printRead">
        {{dataModel}}
      </template>
      <template v-else>
        <a-time-picker 
          v-model:value="dataModel"
          :is-range="widget.options.isRange"
          :placeholder="widget.options.placeholder"
          :start-placeholder="widget.options.startPlaceholder"
          :end-placeholder="widget.options.endPlaceholder"
          :readonly="widget.options.readonly"
          :disabled="!edit || widget.options.disabled"
          :editable="widget.options.editable"
          :clearable="widget.options.clearable"
          :arrowControl="widget.options.arrowControl"
          :value-format="widget.options.format"
          :format="widget.options.format"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :ref="'fm-'+widget.model"
          :size="config.size"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
          popupClassName="fm-popup-index"
        >
        </a-time-picker>
      </template>
    </template>

    <template v-if="widget.type=='date'">
      <template v-if="printRead">
        {{
          widget.options.type == 'dates' ? 
          dataModel.join('、') :
          typeof dataModel == 'object' ? dataModel.join(' ~ ')  : dataModel
          
        }}
      </template>
      <template v-else>
        <a-date-picker
          v-model:value="dataModel"
          :picker="widget.options.type == 'datetime' ? 'date' : widget.options.type"
          :placeholder="widget.options.placeholder"
          :start-placeholder="widget.options.startPlaceholder"
          :end-placeholder="widget.options.endPlaceholder"
          :readonly="widget.options.readonly"
          :disabled="!edit || widget.options.disabled"
          :editable="widget.options.editable"
          :clearable="widget.options.clearable"
          :value-format="widget.options.timestamp ? 'timestamp' : widget.options.format"
          :format="widget.options.format"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :ref="'fm-'+widget.model"
          :size="config.size"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
          :show-time="widget.options.type == 'datetime'"
          dropdownClassName="fm-popup-index"
          v-if="widget.options.type != 'dates' && widget.options.type != 'daterange' && widget.options.type != 'datetimerange' && widget.options.type != 'monthrange'"
        >
        </a-date-picker>
        <a-range-picker
          v-model:value="dataModel"
          :placeholder="[widget.options.startPlaceholder, widget.options.endPlaceholder]"
          :readonly="widget.options.readonly"
          :disabled="!edit || widget.options.disabled"
          :editable="widget.options.editable"
          :clearable="widget.options.clearable"
          :value-format="widget.options.format"
          :format="widget.options.format"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :ref="'fm-'+widget.model"
          :size="config.size"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
          :show-time="widget.options.type == 'datetimerange'"
          :picker="widget.options.type == 'monthrange' ? 'month' : 'date'"
          v-if="widget.options.type == 'daterange' || widget.options.type == 'datetimerange' || widget.options.type == 'monthrange'"
          dropdownClassName="fm-popup-index"
        >
        </a-range-picker>
      </template>
    </template>

    <template v-if="widget.type =='rate'">
      <template v-if="printRead">
        {{dataModel}}
      </template>
      <template v-else>
        <a-rate v-model:value="dataModel"
          :max="widget.options.max"
          :count="widget.options.max"
          :disabled="!edit || widget.options.disabled"
          :allow-half="widget.options.allowHalf"
          :show-score="widget.options.showScore"
          :ref="'fm-'+widget.model"
          :size="config.size"
          :style="{width: isTable ? '100%' : widget.options.width}"
        ></a-rate>
      </template>
    </template>

    <template v-if="widget.type == 'color'">
      <div :style="{width: isTable ? '100%' : widget.options.width, color: '#999'}">
        Not currently supported.
      </div>
    </template>

    <template v-if="widget.type == 'select'">
      <template v-if="printRead">
        <template v-if="widget.options.remote">
          {{
            typeof dataModel == 'object' ?
            (dataModel.map(dm => remoteOptions.find(item => item.value == dm) 
            && remoteOptions.find(item => item.value == dm).label).join('、'))
            : (remoteOptions.find(item => item.value == dataModel) 
            && remoteOptions.find(item => item.value == dataModel).label)
          }}
        </template>
        <template v-else>
          {{
            widget.options.showLabel ? 
            (
              typeof dataModel == 'object' ? 
              dataModel.map(dm => widget.options.options.find(item => item.value == dm) && widget.options.options.find(item => item.value == dm).label).join('、')
              : (widget.options.options.find(item => item.value == dataModel) && widget.options.options.find(item => item.value == dataModel).label)
            ) :
            typeof dataModel == 'object' ? dataModel.join('、') : dataModel
          }}
        </template>
      </template>
      <template v-else>
        <a-select
          v-model:value="dataModel"
          :disabled="!edit || widget.options.disabled"
          :mode="widget.options.multiple ? 'multiple' : 'default'"
          :allow-clear="widget.options.clearable"
          :placeholder="widget.options.placeholder"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :show-search="widget.options.filterable"
          option-filter-prop="children"
          :ref="'fm-'+widget.model"
          :size="config.size"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
          dropdownClassName="fm-select-dropdown"
        >
          <a-select-option v-for="item in (widget.options.remote ? remoteOptions : widget.options.options)" :key="item.value" :value="item.value">
            {{widget.options.showLabel || widget.options.remote?item.label:item.value}}
          </a-select-option>
        </a-select>
      </template>
    </template>

    <template v-if="widget.type=='switch'">
      <template v-if="printRead">
        {{dataModel}}
      </template>
      <template v-else>
        <a-switch
          v-model:checked="dataModel"
          :disabled="!edit || widget.options.disabled"
          :ref="'fm-'+widget.model"
          :size="config.size"
        >
        </a-switch>
      </template>
    </template>

    <template v-if="widget.type=='slider'">
      <template v-if="printRead">
        {{dataModel}}
      </template>
      <template v-else>
        <a-slider 
          v-model:value="dataModel"
          :min="widget.options.min"
          :max="widget.options.max"
          :disabled="!edit || widget.options.disabled"
          :step="widget.options.step"
          :show-input="widget.options.showInput"
          :range="widget.options.range"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :ref="'fm-'+widget.model"
          :size="config.size"
        ></a-slider>
      </template>
    </template>

    <template v-if="widget.type=='imgupload'">
      <fm-upload
        v-model="dataModel"
        :disabled="!edit || widget.options.disabled"
        :readonly="widget.options.readonly || printRead"
        :style="{'width': isTable ? '100%' : widget.options.width}"
        :width="widget.options.size.width"
        :height="widget.options.size.height"
        :token="widget.options.token"
        :domain="widget.options.domain"
        :multiple="widget.options.multiple"
        :limit="widget.options.limit"
        :is-qiniu="widget.options.isQiniu"
        :is-delete="widget.options.isDelete"
        :min="widget.options.min"
        :is-edit="widget.options.isEdit"
        :action="widget.options.action"
        ui="antd"
        :headers="widget.options.headers || []"
        :ref="'fm-'+widget.model"
        :withCredentials="widget.options.withCredentials"
        @on-upload-success="handleOnUploadSuccess"
        @on-upload-error="handleOnUploadError"
        @on-upload-remove="handleOnUploadRemove"
        @on-upload-progress="handleOnUploadProgress"
        :on-select="handleOnUploadSelect"
        :print-read="printRead"
        :size="config.size"
      >
      </fm-upload>
    </template>

    <template v-if="widget.type == 'editor'">
      <template v-if="printRead">
        <div v-html="dataModel" class="ql-editor"></div>
      </template>
      <template v-else>

        <Editor
          v-model="dataModel"
          :custom-style="{width: isTable ? '100%' : widget.options.width, cursor: (!edit || widget.options.disabled) ? 'no-drop' : '', backgroundColor: (!edit || widget.options.disabled) ? '#F5F7FA' : ''}"
          :toolbar="widget.options.customToolbar"
          :disabled="!edit || widget.options.disabled"
          :ref="'fm-'+widget.model"
        ></Editor>
      </template>
    </template>

    <template v-if="widget.type == 'cascader'">
      <template v-if="printRead">
        <template v-if="widget.options.remote">
          {{
            widget.options.multiple ?
            dataModel.map(dm => getCascaderText([...dm], remoteOptions).join(' / ')).join('、')
            : getCascaderText([...dataModel], remoteOptions).join(' / ')
          }}
        </template>
        <template v-else>
          {{
            widget.options.multiple ?
            dataModel.map(dm => getCascaderText([...dm], widget.options.options).join(' / ')).join('、')
            : getCascaderText([...dataModel], widget.options.options).join(' / ')
          }}
        </template>
      </template>
      <template v-else>
        <a-cascader
          v-model:value="dataModel"
          :disabled="!edit || widget.options.disabled"
          :allow-clear="widget.options.clearable"
          :placeholder="widget.options.placeholder"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :options="widget.options.remote ? remoteOptions : widget.options.options"
          :ref="'fm-'+widget.model"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
          :showSearch="widget.options.filterable"
          :change-on-select="widget.options.checkStrictly"
          dropdownClassName="fm-popup-index"
          :multiple="widget.options.multiple"
          :size="config.size"
        >

        </a-cascader>
      </template>
    </template>

    <template v-if="widget.type == 'treeselect'">
      <template v-if="printRead">
        <template v-if="widget.options.remote">
          {{
            typeof dataModel == 'object' ?
              dataModel.map(dm => getTreeText(dm, remoteOptions)).join('、')
              : getTreeText(dataModel, remoteOptions)
          }}
        </template>
        <template v-else>
          {{
            typeof dataModel == 'object' ? 
              dataModel.map(dm => getTreeText(dm, widget.options.options)).join('、')
              : getTreeText(dataModel, widget.options.options)
          }}
        </template>
      </template>
      <template v-else>
         <a-tree-select
          v-model:value="dataModel"
          :disabled="!edit || widget.options.disabled"
          :allow-clear="widget.options.clearable"
          :placeholder="widget.options.placeholder"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :tree-data="widget.options.remote ? remoteOptions : widget.options.options"
          :ref="'fm-'+widget.model"
          @focus="handleOnFocus"
          @blur="handleOnBlur"
          :multiple="widget.options.multiple"
          :showSearch="widget.options.filterable"
          dropdownClassName="fm-popup-index"
          :size="config.size"
        >
        </a-tree-select>
      </template>
    </template>

    <template v-if="widget.type == 'text'">
      <span :ref="'fm-'+widget.model" :style="{width: isTable ? '100%' : (widget.options.width || '100%'), display: 'inline-block'}">{{dataModel}}</span>
    </template>

    <template v-if="widget.type == 'html'">
      <span v-html="dataModel" :ref="'fm-'+widget.model" :style="{width: isTable ? '100%' : (widget.options.width || '100%'), display: 'inline-block'}"></span>
    </template>

    <template v-if="widget.type == 'table'">
      <fm-form-table
        v-model:value="dataModel"
        :columns="widget.tableColumns"
        :models="dataModels"
        :remote="remote"
        :blanks="blanks"
        :disableddata="!edit || widget.options.disabled || printRead"
        :rules="rules"
        :name="widget.model"
        :remote-option="remoteOption"
        :ref="'fm-'+widget.model"
        :preview="preview"
        :platform="platform"
        :data-source-value="dataSourceValue"
        :event-function="eventFunction"
        :widget="widget"
        :container-key="containerKey"
        :print-read="printRead"
        :paging="widget.options.paging"
        :page-size="widget.options.pageSize"
        :config="config"
        :is-add="widget.options.isAdd ?? true"
        :is-delete="widget.options.isDelete ?? true"
        :show-control="widget.options.showControl ?? true"
        :is-dialog="isDialog"
        :dialog-name="dialogName"
      >
        <template v-slot:[blank.name]="scope" v-for="blank in blanks">
          <slot :name="blank.name" :model="scope.model"></slot>
        </template>
      </fm-form-table>
    </template>

    <template v-if="widget.type == 'subform'">
      <fm-sub-form
        v-model:value="dataModel"
        :list="widget.list"
        :models="dataModels"
        :remote="remote"
        :blanks="blanks"
        :disableddata="!edit || widget.options.disabled || printRead"
        :rules="rules"
        :name="widget.model"
        :remote-option="remoteOption"
        :ref="'fm-'+widget.model"
        :preview="preview"
        :platform="platform"
        :data-source-value="dataSourceValue"
        :event-function="eventFunction"
        :widget="widget"
        :print-read="printRead"
        :paging="widget.options.paging"
        :page-size="widget.options.pageSize"
        :config="config"
        :container-key="containerKey"
        :show-control="widget.options.showControl"
        :is-delete="widget.options.isDelete ?? true"
        :is-add="widget.options.isAdd ?? true"
        :is-dialog="isDialog"
        :dialog-name="dialogName"
      >
        <template v-slot:[blank.name]="scope" v-for="blank in blanks">
          <slot :name="blank.name" :model="scope.model"></slot>
        </template>
      </fm-sub-form>
    </template>

    <template v-if="widget.type == 'fileupload'">
      <fm-file-upload
        v-model="dataModel"
        :disabled="!edit || widget.options.disabled"
        :style="{'width': isTable ? '100%' : widget.options.width}"
        :token="widget.options.token"
        :domain="widget.options.domain"
        :multiple="widget.options.multiple"
        :limit="widget.options.limit"
        :is-qiniu="widget.options.isQiniu"
        :min="widget.options.min"
        :action="widget.options.action"
        :tip="widget.options.tip"
        ui="antd"
        :headers="widget.options.headers || []"
        :ref="'fm-'+widget.model"
        :withCredentials="widget.options.withCredentials"
        :print-read="printRead"
        @on-upload-success="handleOnUploadSuccess"
        @on-upload-error="handleOnUploadError"
        @on-upload-remove="handleOnUploadRemove"
        @on-upload-progress="handleOnUploadProgress"
        :on-select="handleOnUploadSelect"
        :size="config.size"
      >
      </fm-file-upload>
    </template>

    <template v-if="widget.type == 'button'">
      <a-button
        :disabled="!edit || widget.options.disabled"
        :size="widget.options.buttonSize"
        :type="widget.options.buttonType == 'text' ? 'link' : widget.options.buttonType"
        :shape="widget.options.buttonCircle ? 'circle' : (widget.options.buttonRound ? 'round' : null)"
        :ghost="widget.options.buttonPlain"
        :style="{width: widget.options.width}"
        :ref="'fm-'+widget.model"
        @click="handleOnClick"
      >{{widget.options.buttonName}}
      </a-button>
    </template>

    <template v-if="widget.type == 'link'">
      <div :style="{width: isTable ? '100%' : widget.options.width, color: '#999'}">
        Not currently supported.
      </div>
    </template>

    <template v-if="widget.type == 'steps'">
      <a-steps :current="dataModel" 
        :ref="'fm-'+widget.model"
        :space="widget.options.space"
        :direction="widget.options.direction"
        :status="widget.options.processStatus"
        :style="{'line-height': 'normal'}"
      >
        <template v-for="(item, index) in (widget.options.remote ? remoteOptions : widget.options.steps)" :key="index">
           <a-step 
            :title="widget.options.remote ? item.value : item.title" 
            :description="widget.options.remote ? item.label : item.description"  ></a-step>
        </template>
      </a-steps>
    </template>

    <template v-if="widget.type == 'pagination'">
      <a-pagination
        v-model:current="dataModel"
        :page-size="widget.options.pageSize"
        :pager-count="widget.options.pagerCount"
        :disabled="widget.options.disabled"
        :background="widget.options.background"
        :total="widget.options.total"
        :show-total="total => `${$t('fm.config.widget.total')} ${total}`"
        show-less-items
        :show-size-changer="false"
        :size="widget.options.background ? '' : 'small'"
      />
    </template>

    <template v-if="widget.type == 'transfer'">
      <template v-if="printRead">
        <template v-if="widget.options.remote">
          {{
            dataModel.map(dm => remoteOptions.find(item => 
              item.key == dm)?.title).join('、')
          }}
        </template>
        <template v-else>
          {{
            dataModel.map(dm => widget.options.data.find(item => 
              item.key == dm)?.label).join('、')
          }}
        </template>
      </template>
      <template v-else>
         <a-transfer
          v-model:target-keys="dataModel"
          :disabled="!edit || widget.options.disabled"
          :data-source="widget.options.remote ? remoteOptions : dataOnly"
          :render="item => `${item.title}`"
          :showSearch="widget.options.filterable"
          :titles="widget.options.titles"
          :style="{width: isTable ? '100%' : widget.options.width}"
          :ref="'fm-'+widget.model"
        ></a-transfer>
      </template>
    </template>
  </span>
</template>

<script>
import FmUpload from '../Upload/index.vue'
import FmFormTable from './FormTable.vue'
import FmFileUpload from '../Upload/file.vue'
import { EventBus } from '../../util/event-bus'
import Editor from '../Editor/index.vue'
import FmSubForm from './SubForm.vue'

export default {
  name: 'generate-element-item',
  components: {
    FmUpload,
    FmFormTable,
    FmFileUpload,
    Editor,
    FmSubForm
  },
  props: ['config', 'widget', 'modelValue', 'models', 'remote', 'isTable', 'blanks', 'disabled', 'edit', 'remoteOption', 'rules', 'platform', 'preview', 'dataSourceValue', 'eventFunction', 'rowIndex', 'tableName', 'containerKey', 'printRead', 'isMobile', 'isSubform', 'subName', 'isDialog', 'dialogName'],
  emits: ['on-table-change', 'update:modelValue', 'update:widget'],
  data () {
    return {
      dataModel: this.modelValue,
      dataModels: this.models,
      key: new Date().getTime(),
      modelName: this.widget.model,
      dataOnly : this.widget.options?.data?.map(item => ({...item, title: item.label})),
      remoteOptions: [],
      dynamicEvents: this.handleOnDynamicEvent()
    }
  },
  inject: ['generateComponentInstance', 'deleteComponentInstance', 'eventScriptConfig'],
  created () {
    
    if (this.widget.options.remote 
      && (Object.keys(this.widget.options).indexOf('remoteType') >= 0 ? this.widget.options.remoteType == 'func' : true)
      && this.remote[this.widget.options.remoteFunc]) {

      this.remote[this.widget.options.remoteFunc]((data) => {
        this.loadOptions(data)
      })
    }

    if (this.widget.options.remote 
      && this.widget.options.remoteType == 'option' 
      && this.remoteOption[this.widget.options.remoteOption]) {
      
      this.loadOptions(this.remoteOption[this.widget.options.remoteOption])
    }

    if (this.widget.options.remote 
      && this.widget.options.remoteType == 'datasource' 
      && this.dataSourceValue) {

      let options = this.getDataSourceOptions()
      
      options && options.value && this.loadOptions(options.value)
    }

    if ((this.widget.type === 'imgupload' || this.widget.type === 'fileupload') && this.widget.options.isQiniu) {
      
      this.loadUploadConfig()
    }

    if (this.widget.type == 'component') {

      const _pthis = this

      this.$options.components[`component-${this.widget.key}-${this.key}`] = {
        template: `${this.widget.options.template}`,
        props: ['modelValue'],
        emits: ['update:modelValue'],
        data: () => ({
          dataModel: this.modelValue
        }),
        watch: {
          dataModel (val) {

            if (this.ui == 'antd') {
              EventBus.$emit('on-field-change', this.$attrs.id, val)
            } else {
              this.$emit('update:modelValue', val)
            }
          },
          modelValue (val) {
            this.dataModel = val
          }
        },
        methods: {
          triggerEvent (eventName, arg) {
            if (_pthis.eventScriptConfig) {
              let currentEventScript = _pthis.eventScriptConfig.find(item => item.name == eventName)

              if (currentEventScript) {
                if (_pthis.isTable && _pthis.tableName) {
                  _pthis.eventFunction[currentEventScript.key]({
                    field: _pthis.widget.model,
                    table: _pthis.tableName, 
                    rowIndex: _pthis.rowIndex,
                    dialog: _pthis.isDialog ? _pthis.dialogName : null,
                    currentRef: this,
                    $eventArgs: arg})
                } else if (_pthis.isSubform && _pthis.subName) {
                  _pthis.eventFunction[currentEventScript.key]({
                    field: _pthis.widget.model,
                    subform: _pthis.subName, 
                    rowIndex: _pthis.rowIndex,
                    dialog: _pthis.isDialog ? _pthis.dialogName : null,
                    currentRef: this,
                    $eventArgs: arg})
                } else if (_pthis.isDialog && _pthis.dialogName) {
                  _pthis.eventFunction[currentEventScript.key]({
                    field: _pthis.widget.model,
                    dialog: _pthis.dialogName,
                    currentRef: this,
                    $eventArgs: arg
                  })
                } else {
                  _pthis.eventFunction[currentEventScript.key]({
                    field: _pthis.widget.model, 
                    currentRef: this,
                    $eventArgs: arg})
                }
              }
            }
          }
        }
      }
    }
  },
  mounted () {
    let key = this.widget.model

    if (this.isDialog) {
      key = `${this.dialogName}.${this.widget.model}`

      if (this.isTable) {
        key = `${this.dialogName}.${this.isMobile ? 'm' : ''}${this.tableName}.${this.rowIndex}.${this.widget.model}` 
      }
      if (this.isSubform) {
        key = `${this.dialogName}.${this.subName}.${this.rowIndex}.${this.widget.model}`
      }
    } else {
      if (this.isTable) {
        key = `${this.isMobile ? 'm' : ''}${this.tableName}.${this.rowIndex}.${this.widget.model}` 
      }
      if (this.isSubform) {
        key = `${this.subName}.${this.rowIndex}.${this.widget.model}`
      }
    }

    this.generateComponentInstance && this.generateComponentInstance(
      key, 
      this.$refs['fm-'+this.widget.model]
    )
  },
  beforeUnmount () {
    let key = this.widget.model

    if (this.isDialog) {
      key = `${this.dialogName}.${this.widget.model}`

      if (this.isTable) {
        key = `${this.dialogName}.${this.isMobile ? 'm' : ''}${this.tableName}.${this.rowIndex}.${this.widget.model}` 
      }
      if (this.isSubform) {
        key = `${this.dialogName}.${this.subName}.${this.rowIndex}.${this.widget.model}`
      }
    } else {
      if (this.isTable) {
        key = `${this.isMobile ? 'm' : ''}${this.tableName}.${this.rowIndex}.${this.widget.model}` 
      }
      if (this.isSubform) {
        key = `${this.subName}.${this.rowIndex}.${this.widget.model}`
      }
    }
    
    this.deleteComponentInstance && this.deleteComponentInstance(key)
  },
  methods: {
    handleOnDynamicEvent () {
      let currentEvents = {}

      for (let i in this.widget.events) {
        let funcKey = this.widget.events[i]

        funcKey && (
          currentEvents[i] = this.callbackDynamicFunc(funcKey)
        )
      }

      return currentEvents
    },
    callbackDynamicFunc (funcKey) {
      let callback = (...arg) => {
        if (this.isTable && this.tableName) {
          this.eventFunction[funcKey]({
            field: this.widget.model,
            table: this.tableName, 
            rowIndex: this.rowIndex,
            dialog: this.isDialog ? this.dialogName : null,
            currentRef: this.$refs['fm-'+this.widget.model],
            $eventArgs: arg})
        } else if (this.isSubform && this.subName) {
          this.eventFunction[funcKey]({
            field: this.widget.model,
            subform: this.subName, 
            rowIndex: this.rowIndex,
            dialog: this.isDialog ? this.dialogName : null,
            currentRef: this.$refs['fm-'+this.widget.model],
            $eventArgs: arg})
        } else if (this.isDialog && this.dialogName) {
          this.eventFunction[funcKey]({
            field: this.widget.model,
            dialog: this.dialogName,
            currentRef: this.$refs['fm-'+this.widget.model],
            $eventArgs: arg
          })
        } else {
          this.eventFunction[funcKey]({
            field: this.widget.model, 
            currentRef: this.$refs['fm-'+this.widget.model],
            $eventArgs: arg
          })
        }
      }
      return callback
    },
    loadOptions (data) {
      if (!Array.isArray(data)) return
      this.remoteOptions = data.map(item => {
        
        if (this.widget.options.props.children && this.widget.options.props.children.length && Object.keys(item).includes(this.widget.options.props.children)) {
          return {
            value: item[this.widget.options.props.value],
            label: item[this.widget.options.props.label],
            children: this.processRemoteProps(item[this.widget.options.props.children], this.widget.options.props)
          }
        } else {
          if (this.widget.type == 'steps') {
            return {
              value: item[this.widget.options.props.title],
              label: item[this.widget.options.props.description]
            }
          } else if (this.widget.type == 'transfer') {
            return {
              key: item[this.widget.options.props.key],
              title: item[this.widget.options.props.label],
              disabled: item[this.widget.options.props.disabled]
            }
          } else {
            return {
              value: item[this.widget.options.props.value],
              label: item[this.widget.options.props.label]
            }
          }
        }
        
      })
    },
    processRemoteProps (children, props) {
      if (children && children.length) {
        return children.map(item => {
          if (this.processRemoteProps(item[props.children], props).length) {
            return {
              value: item[props.value],
              label: item[props.label],
              children: this.processRemoteProps(item[props.children], props)
            }
          } else{
            return {
              value: item[props.value],
              label: item[props.label],
            }
          }
        })
      } else {
        return []
      }
    },
    loadUploadConfig () {
      if (this.widget.options.tokenType === 'func') {
        !this.widget.options.token && this.remote[this.widget.options.tokenFunc]((data) => {
          this.widget.options.token = data
        })
      } else {
        if (this.dataSourceValue) {
          let token = this.getDataSourceOptions('tokenDataSource')

          token && token.value && (this.widget.options.token = token.value)
        }
      }
    },
    handleOnClick () {
      this.execFunction('onClick', {})
    },
    handleOnFocus () {
      this.execFunction('onFocus', {})
    },
    handleOnBlur () {

      this.execFunction('onBlur', {})
    },
    handleOnUploadSelect (file) {
      this.execFunction('onSelect', {file: file})
    },
    handleOnUploadSuccess (file) {
      this.execFunction('onUploadSuccess', {file: file})
    },
    handleOnUploadError (file) {
      this.execFunction('onUploadError', {file: file})
    },
    handleOnUploadProgress (file) {
      this.execFunction('onUploadProgress', {file: file})
    },
    handleOnUploadRemove (file) {
      this.execFunction('onRemove', {file: file})
    },
    execFunction (method, arg) {
      if (this.widget.events && this.widget.events[method]) {
        let funcKey = this.widget.events[method]

        if (this.isTable && this.tableName) {
          this.eventFunction[funcKey]({
            field: this.widget.model,
            table: this.tableName, 
            rowIndex: this.rowIndex,
            dialog: this.isDialog ? this.dialogName : null,
            currentRef: this.$refs['fm-'+this.widget.model],
            ...arg,
          })
        } else if (this.isSubform && this.subName) {
          this.eventFunction[funcKey]({
            field: this.widget.model,
            subform: this.subName, 
            rowIndex: this.rowIndex,
            dialog: this.isDialog ? this.dialogName : null,
            currentRef: this.$refs['fm-'+this.widget.model],
            ...arg
          })
        } else if (this.isDialog && this.dialogName) {
          this.eventFunction[funcKey]({
            field: this.widget.model,
            dialog: this.subName,
            currentRef: this.$refs['fm-'+this.widget.model],
            ...arg
          })
        } else {
          this.eventFunction[funcKey]({
            field: this.widget.model, 
            currentRef: this.$refs['fm-'+this.widget.model],
            ...arg
          })
        }
      }
    },
    getCascaderText (value, options, texts = []) {
      if (value.length >= 1) {
        let currentOpt = options.find(opt => opt.value == value[0])
        if (currentOpt) {
          texts.push(currentOpt.label)
        }
        value.splice(0, 1)
        return this.getCascaderText(value, currentOpt.children, texts)
      } else if (value.length == 0) {
        return texts
      }
    },
    getTreeText (value, options) {
      for (let i = 0; i < options.length; i++) {
        let currentOpt = options[i]

        if (currentOpt.value == value) {
          return currentOpt.label
        }

        if (currentOpt.children && currentOpt.children.length > 0) {
          let res = this.getTreeText(value, currentOpt.children)

          if (res == '-') {
            continue
          } else {
            return res
          }
        }
      }

      return '-'
    },
    getDataSourceOptions (remoteName = 'remoteDataSource') {
      let key = this.widget.model + '.' + this.widget.options[remoteName]

      if (this.isDialog) {
        key = this.dialogName + '.' + this.widget.model + '.' + this.widget.options[remoteName]

        if (this.isTable) {
          key = this.dialogName + '.' + this.tableName + '.' + this.widget.model + '.' + this.widget.options[remoteName]
        }
        if (this.isSubform) {
          key = this.dialogName + '.' + this.subName + '.' + this.widget.model + '.' + this.widget.options[remoteName]
        }
      } else {
        if (this.isTable) {
          key = this.tableName + '.' + this.widget.model + '.' + this.widget.options[remoteName]
        }
        if (this.isSubform) {
          key = this.subName + '.' + this.widget.model + '.' + this.widget.options[remoteName]
        }
      }

      return this.dataSourceValue.find(item => item.key === key)
    }
  },
  watch: {
    modelValue (val) {
      this.dataModel = val
    },

    dataModel (val, oldValue) {
      this.$emit('update:modelValue', val)

      if (this.isTable && this.tableName) {

        EventBus.$emit('on-validate-' + this.containerKey, [this.tableName, this.rowIndex, this.widget.model], this.containerKey)

        this.$emit('on-table-change', {
          value: val, 
          field: this.widget.model, 
          table: this.tableName, 
          rowIndex: this.rowIndex,
          dialog: this.isDialog ? this.dialogName : null,
          currentRef: this.$refs['fm-'+this.widget.model],
          haveEvent: this.widget.events && this.widget.events.onChange
        })
      }
    },
    'remoteOption': {
      deep: true,
      handler: function (val) {
        if (Object.keys(this.remoteOption).indexOf(this.widget.options.remoteOption) >= 0
          && this.widget.options.remote 
          && this.widget.options.remoteType == 'option' 
        ) {
          this.loadOptions(this.remoteOption[this.widget.options.remoteOption])
        }
      }
    },
    'dataSourceValue': {
      deep: true,
      handler: function(val) {

        if (this.dataSourceValue) {
          let options = this.getDataSourceOptions()
      
          options && options.value && this.loadOptions(options.value)
        }

        if ((this.widget.type === 'imgupload' || this.widget.type === 'fileupload') && this.widget.options.isQiniu) {
      
          this.loadUploadConfig()
        }
      }
    }
  }
}
</script>
