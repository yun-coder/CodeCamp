<template>
  <div class="fm-form-item" :data-id="widget.model" v-if="widget.key">
    <a-form-item 
      v-if="widget.type != 'divider' && widget.type != 'alert' &&  (isSubform ? display[widget.model] && !subHideFields[rowIndex][widget.model] : display[widget.model])" 
      
      :name="isDialog ? (isSubform ? [dialogName, subName, rowIndex, widget.model] : [dialogName, widget.model]) : (isSubform ? [subName, rowIndex, widget.model] : widget.model)"
      :rules="rules[ruleProp]"

      :class="{
        [widget.options && widget.options.customClass]: widget.options && widget.options.customClass?true: false,
        'no-label-form-item': widget.options.isLabelWidth && widget.options.labelWidth == 0,
        'no-label-left': widget.name === ''
      }"
      :label="widget.options.hideLabel ? '' : widget.name"
      :key="widget.key"
      :required="widget.options.required"
      ref="generateFormItem"
      :colon="false"
      validateFirst
    >
      <generate-element-item 
        :blanks="blanks" 
        :is-table="false" 
        :widget="widget" 
        :models="dataModels"
        :remote="remote"
        :edit="edit && (isSubform ? !subDisabledFields[rowIndex][widget.model] : true)"
        :remote-option="remoteOption"
        :key="widget.key"
        :rules="rules"
        v-model="dataModel"
        :platform="platform"
        :preview="preview"
        :data-source-value="dataSourceValue"
        :event-function="eventFunction"
        :container-key="containerKey"
        :print-read="printRead"
        :config="config"
        :is-subform="isSubform"
        :row-index="rowIndex"
        :sub-name="subName"
        :is-dialog="isDialog"
        :dialog-name="dialogName"
        ref="generateElementItem"
      >
        
        <template v-slot:[blank.name]="scope" v-for="blank in blanks">
          <slot :name="blank.name" :model="scope.model"></slot>
        </template>
      </generate-element-item>
    </a-form-item>

    <a-form-item v-if="widget.type == 'divider' && (isSubform ? display[widget.model] && !subHideFields[rowIndex][widget.model] : display[widget.model])" :wrapperCol="{span: 0, offset: 0}">
      <a-divider 
        :orientation="widget.options.contentPosition"
      >
        {{widget.name}}
      </a-divider>
    </a-form-item>

    <a-form-item v-if="widget.type == 'alert' && (isSubform ? display[widget.model] && !subHideFields[rowIndex][widget.model] : display[widget.model])"  :wrapperCol="{span: 0, offset: 0}">
      <a-alert 
        :message="widget.options.title"
        :type="widget.options.type"
        :description="widget.options.description"
        :closable="widget.options.closable"
        :center="widget.options.center"
        :show-icon="widget.options.showIcon"
        :effect="widget.options.effect"
        :style="{width: widget.options.width}"
        @close="display[widget.model] = false"
      ></a-alert>
    </a-form-item>
  </div>
  
</template>

<script>
import GenerateElementItem from './GenerateElementItem.vue'
import { EventBus } from '../../util/event-bus.js'

export default {
  components: {
    GenerateElementItem
  },
  props: ['config', 'widget', 'models', 'rules', 'remote', 'blanks', 'display', 'edit', 'remoteOption', 'platform', 'preview', 'containerKey', 'dataSourceValue', 'eventFunction', 'printRead', 'isSubform', 'rowIndex', 'subName', 'subHideFields', 'subDisabledFields', 'isDialog', 'dialogName'],
  data () {
    return {
      
      dataModel: this.models[this.widget.model],
      dataModels: this.models
    }
  },
  computed: {
    labelWidth () {
      return this.widget.options.hideLabel ? '0px' : (this.widget.options.isLabelWidth ? this.widget.options.labelWidth + 'px' : this.config.labelWidth + 'px')
    },
    ruleProp () {
      let currentProp = this.widget.model

      if (this.isDialog) {
        currentProp = this.dialogName + '.' + this.widget.model

        if (this.isSubform) {
          currentProp = this.dialogName + '.' + this.subName + '.' + this.widget.model
        }
      } else {
        if (this.isSubform) {
          currentProp = this.subName + '.' + this.widget.model
        }
      }

      return currentProp
    }
  },
  inject: {
    setSubformData: {
      default: () => {}
    },
    setDialogData: {
      default: () => {}
    }
  },
  methods: {
  },
  watch: {
    dataModel: {
      deep: true,
      handler (val) {

        if (this.isSubform) {
          this.setSubformData(val, this.rowIndex, this.widget.model)

          EventBus.$emit('on-validate-' + this.containerKey, [this.subName, this.rowIndex, this.widget.model], this.containerKey)
        } else if (this.isDialog) {
          this.setDialogData(val, this.widget.model)

          EventBus.$emit('on-validate-' + this.containerKey, [this.dialogName, this.widget.model], this.containerKey)
        } else {
          EventBus.$emit('on-change-' + this.containerKey, val, this.widget.model, this.containerKey)
        
          EventBus.$emit('on-validate-' + this.containerKey, this.widget.model, this.containerKey)
        }

        // 执行 onChange 方法
        if (this.widget.events && this.widget.events.onChange) {
          let funcKey = this.widget.events.onChange
          
          if (this.isSubform) {
            this.eventFunction[funcKey]({
              value: val,
              field: this.widget.model,
              rowIndex: this.rowIndex,
              subform: this.subName,
              dialog: this.isDialog ? this.dialogName : null,
              currentRef: this.$refs?.['generateElementItem']?.$refs?.[`fm-${this.widget.model}`]
            })
          } else if (this.isDialog) {
            this.eventFunction[funcKey]({
              value: val,
              field: this.widget.model,
              dialog: this.dialogName,
              currentRef: this.$refs?.['generateElementItem']?.$refs?.[`fm-${this.widget.model}`]
            })
          } else {
            this.eventFunction[funcKey]({
              value: val, 
              field: this.widget.model,
              currentRef: this.$refs?.['generateElementItem']?.$refs?.[`fm-${this.widget.model}`]
            })
          }
        }
      }
    },
    models: {
      deep: true,
      handler (val) {
        this.dataModels = val
        this.dataModel = val[this.widget.model]
      }
    }
  }
}
</script>

<style lang="scss" >
.fm-form, .fm-generate-ant-dialog{
  .fm-form-item{

    .ant-form-item{
      .ant-col{
        max-width: none;
      }

      .ant-form-item-label{
        flex: 0 0 auto;
      }

      .ant-form-item-control{
        flex: 1;
      }
    }

    .ant-form-item{
      .ant-form-item-label{
        width: v-bind(labelWidth);
      }
    }

    .no-label-left{
      .ant-form-item-control{
        margin-left: v-bind(labelWidth);
      }
    }
  }
}
</style>